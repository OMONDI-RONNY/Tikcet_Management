using Microsoft.EntityFrameworkCore;
using NSCore.DatabaseContext;
using NSCore.SearchOption;
using NSCore.Validation;
using NSEncryption;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using UserManager.Data;
using UserManager.Dtos;
using UserManager.Interfaces;
using UserManager.Models;

namespace UserManager.DbImplementation;

/// <summary>
/// Base implementation class for user management operations.
/// Contains common logic shared across all database providers.
/// </summary>
public abstract class BaseDbImplementation<TRole, TStatus, TPermission, TTheme> : INsContextInit,
    IManageUsers<TRole, TStatus, TPermission, TTheme>, IDisposable
    where TRole : struct, Enum
    where TStatus : struct, Enum
    where TPermission : struct, Enum
    where TTheme : struct, Enum
{
    protected bool _disposed = false;
    protected readonly IDbContextFactory<AppDbContext> _contextFactory;

    #region Compiled Queries
    // Compiled queries for frequently executed operations
    protected static readonly Func<AppDbContext, int, Task<UserModel?>> GetUserByIdQuery =
        EF.CompileAsyncQuery((AppDbContext context, int userId) =>
            context.Users.AsNoTracking()
                .Where(u => u.Id == userId)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = new List<UserMetadata>()
                })
                .FirstOrDefault());

    protected static readonly Func<AppDbContext, int, Task<UserModel?>> GetUserByIdWithMetadataQuery =
        EF.CompileAsyncQuery((AppDbContext context, int userId) =>
            context.Users.AsNoTracking()
                .Include(u => u.Metadata)
                .Where(u => u.Id == userId)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = u.Metadata != null ? u.Metadata.Select(m => new UserMetadata
                    {
                        Id = m.Id,
                        UserId = m.UserId,
                        Key = m.Key,
                        Value = m.Value
                    }).ToList() : new List<UserMetadata>()
                })
                .FirstOrDefault());

    protected static readonly Func<AppDbContext, string, Task<UserModel?>> GetUserByEmailQuery =
        EF.CompileAsyncQuery((AppDbContext context, string email) =>
            context.Users.AsNoTracking()
                .Where(u => u.Email == email)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = new List<UserMetadata>()
                })
                .FirstOrDefault());

    protected static readonly Func<AppDbContext, string, Task<UserModel?>> GetUserByEmailWithMetadataQuery =
        EF.CompileAsyncQuery((AppDbContext context, string email) =>
            context.Users.AsNoTracking()
                .Include(u => u.Metadata)
                .Where(u => u.Email == email)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = u.Metadata != null ? u.Metadata.Select(m => new UserMetadata
                    {
                        Id = m.Id,
                        UserId = m.UserId,
                        Key = m.Key,
                        Value = m.Value
                    }).ToList() : new List<UserMetadata>()
                })
                .FirstOrDefault());

    protected static readonly Func<AppDbContext, string, Task<UserModel?>> GetUserByUsernameQuery =
        EF.CompileAsyncQuery((AppDbContext context, string userName) =>
            context.Users.AsNoTracking()
                .Where(u => u.UserName == userName)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = new List<UserMetadata>()
                })
                .FirstOrDefault());

    protected static readonly Func<AppDbContext, string, Task<UserModel?>> GetUserByUsernameWithMetadataQuery =
        EF.CompileAsyncQuery((AppDbContext context, string userName) =>
            context.Users.AsNoTracking()
                .Include(u => u.Metadata)
                .Where(u => u.UserName == userName)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = u.Metadata != null ? u.Metadata.Select(m => new UserMetadata
                    {
                        Id = m.Id,
                        UserId = m.UserId,
                        Key = m.Key,
                        Value = m.Value
                    }).ToList() : new List<UserMetadata>()
                })
                .FirstOrDefault());

    protected static readonly Func<AppDbContext, string, Task<bool>> EmailExistsQuery =
        EF.CompileAsyncQuery((AppDbContext context, string email) =>
            context.Users.Any(u => u.Email == email));

    protected static readonly Func<AppDbContext, string, Task<bool>> UsernameExistsQuery =
        EF.CompileAsyncQuery((AppDbContext context, string userName) =>
            context.Users.Any(u => u.UserName == userName));

    protected static readonly Func<AppDbContext, int, int, IAsyncEnumerable<UserModel>> GetPagedUsersQuery =
        EF.CompileAsyncQuery((AppDbContext context, int skip, int take) =>
            context.Users.AsNoTracking()
                .OrderBy(u => u.Id)
                .Skip(skip)
                .Take(take)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = new List<UserMetadata>()
                }));

    protected static readonly Func<AppDbContext, Task<int>> GetTotalUsersCountQuery =
        EF.CompileAsyncQuery((AppDbContext context) =>
            context.Users.Count());

    protected static readonly Func<AppDbContext, int, Task<bool>> UserExistsByIdQuery =
        EF.CompileAsyncQuery((AppDbContext context, int userId) =>
            context.Users.Any(u => u.Id == userId));
    #endregion

    #region Constructor
    /// <summary>
    /// Initializes a new instance of the BaseDbImplementation class.
    /// </summary>
    /// <param name="contextFactory">The database context factory.</param>
    protected BaseDbImplementation(IDbContextFactory<AppDbContext> contextFactory)
    {
        _contextFactory = contextFactory ?? throw new ArgumentNullException(nameof(contextFactory));
        InitializeConnection();
    }

    /// <summary>
    /// Initializes the database connection. Can be overridden by derived classes.
    /// </summary>
    protected virtual void InitializeConnection()
    {
        try
        {
            using var context = _contextFactory.CreateDbContext();
            if (!context.Database.CanConnect())
            {
                throw new InvalidOperationException("Unable to connect to the database. Please check the connection string and database server.");
            }
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Failed to initialize the database context.", ex);
        }
    }
    #endregion

    #region Helper Methods Using Compiled Queries
    /// <summary>
    /// Checks if a user exists by email using compiled query.
    /// </summary>
    /// <param name="email">The email to check.</param>
    /// <returns>True if user exists, false otherwise.</returns>
    protected async Task<bool> UserExistsByEmailAsync(string email)
    {
        using var context = _contextFactory.CreateDbContext();
        return await EmailExistsQuery(context, email);
    }

    /// <summary>
    /// Checks if a user exists by username using compiled query.
    /// </summary>
    /// <param name="userName">The username to check.</param>
    /// <returns>True if user exists, false otherwise.</returns>
    protected async Task<bool> UserExistsByUsernameAsync(string userName)
    {
        using var context = _contextFactory.CreateDbContext();
        return await UsernameExistsQuery(context, userName);
    }

    /// <summary>
    /// Checks if a user exists by ID using compiled query.
    /// </summary>
    /// <param name="userId">The user ID to check.</param>
    /// <returns>True if user exists, false otherwise.</returns>
    protected async Task<bool> UserExistsByIdAsync(int userId)
    {
        using var context = _contextFactory.CreateDbContext();
        return await UserExistsByIdQuery(context, userId);
    }
    #endregion

    #region Migration Methods
    /// <inheritdoc/>
    /// <summary>
    /// Creates a database context for migration operations.
    /// Can be overridden by derived classes to provide database-specific contexts.
    /// </summary>
    /// <returns>The database context to use for migrations.</returns>
    protected virtual AppDbContext CreateMigrationContext()
    {
        return _contextFactory.CreateDbContext();
    }

    /// <summary>
    /// Applies migrations to the database asynchronously.
    /// This method uses the database-specific context for proper migration discovery.
    /// </summary>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    public virtual async Task ApplyMigrationsAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            using var context = CreateMigrationContext();
            var canConnect = await context.Database.CanConnectAsync();
            if (!canConnect)
            {
                throw new InvalidOperationException("Database doesn't exist. Please create and configure it first.");
            }

            var appliedMigrations = await context.Database.GetAppliedMigrationsAsync(cancellationToken);
            var pendingMigrations = await context.Database.GetPendingMigrationsAsync(cancellationToken);

            if (pendingMigrations.Any())
            {
                await context.Database.MigrateAsync(cancellationToken);
            }
        }
        catch (Exception ex) when (IsTableAlreadyExistsError(ex))
        {
            await HandleMigrationConflictAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            throw new Exception($"Migration failed: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Determines if the exception indicates a table already exists error.
    /// Can be overridden by derived classes for database-specific error handling.
    /// </summary>
    /// <param name="ex">The exception to check.</param>
    /// <returns>True if the exception indicates a table already exists error.</returns>
    protected virtual bool IsTableAlreadyExistsError(Exception ex)
    {
        // Base implementation - override in derived classes for specific database error codes
        return false;
    }

    /// <summary>
    /// Marks a migration as applied in the database.
    /// Can be overridden by derived classes for database-specific implementation.
    /// </summary>
    /// <param name="migrationId">The migration ID to mark as applied.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    protected virtual async Task MarkMigrationAsAppliedAsync(string migrationId, CancellationToken cancellationToken)
    {
        using var context = _contextFactory.CreateDbContext();
        var provider = context.Database.ProviderName;
        var productVersion = typeof(DbContext).Assembly.GetName().Version?.ToString() ?? "8.0.0";

        // This is a generic implementation - override in derived classes for database-specific SQL
        var rawQuery = GetMarkMigrationSql();
        var parameters = GetMarkMigrationParameters(migrationId, productVersion);

        await context.Database.ExecuteSqlRawAsync(rawQuery, parameters, cancellationToken);
    }

    /// <summary>
    /// Gets the SQL statement for marking a migration as applied.
    /// Must be overridden by derived classes.
    /// </summary>
    /// <returns>The SQL statement.</returns>
    protected abstract string GetMarkMigrationSql();

    /// <summary>
    /// Gets the parameters for marking a migration as applied.
    /// Must be overridden by derived classes.
    /// </summary>
    /// <param name="migrationId">The migration ID.</param>
    /// <param name="productVersion">The product version.</param>
    /// <returns>The parameters array.</returns>
    protected abstract object[] GetMarkMigrationParameters(string migrationId, string productVersion);

    private async Task HandleMigrationConflictAsync(CancellationToken cancellationToken)
    {
        try
        {
            using var context = _contextFactory.CreateDbContext();
            var allMigrations = context.Database.GetMigrations().ToList();
            var pendingMigrations = await context.Database.GetPendingMigrationsAsync(cancellationToken);
            var latestMigration = allMigrations.LastOrDefault();

            if (latestMigration != null && pendingMigrations.Contains(latestMigration))
            {
                foreach (var migration in pendingMigrations)
                {
                    await MarkMigrationAsAppliedAsync(migration, cancellationToken);
                }
            }
            else
            {
                throw new InvalidOperationException("Could not resolve conflict: No valid latest migration found.");
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to resolve migration conflict: {ex.Message}", ex);
        }
    }
    #endregion

    /// <inheritdoc/>
    public virtual bool IsContextCreated()
    {
        try
        {
            using var context = _contextFactory.CreateDbContext();
            return context.Database.CanConnect();
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Failed to check if the context is created.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<List<UserModel>> FetchUsersAsync(int from = 0, int pageSize = 10, bool includeMetadata = false)
    {
        if (from < 0)
            throw new ArgumentException("From index cannot be negative.", nameof(from));

        if (pageSize <= 0)
            throw new ArgumentException("Page size must be greater than zero.", nameof(pageSize));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            var query = context.Users.AsNoTracking();

            if (includeMetadata)
            {
                query = query.Include(u => u.Metadata);
            }

            var users = await query
                .OrderBy(u => u.Id)
                .Skip(from)
                .Take(pageSize)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = includeMetadata && u.Metadata != null
                        ? u.Metadata.Select(m => new UserMetadata
                        {
                            Id = m.Id,
                            UserId = m.UserId,
                            Key = m.Key,
                            Value = m.Value
                        }).ToList()
                        : new List<UserMetadata>()
                })
                .ToListAsync();

            return users;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while fetching users.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> AddUserAsync(CreateUserDto userDto)
    {
        if (userDto == null)
            throw new ArgumentNullException(nameof(userDto));

        InputValidator.Validate([userDto.FirstName, userDto.LastName, userDto.Email, userDto.UserName, userDto.Password]);

        if (!new EmailAddressAttribute().IsValid(userDto.Email))
            throw new ArgumentException("Invalid email format.", nameof(userDto.Email));

        if (userDto.Metadata != null && userDto.Metadata.Any(m => string.IsNullOrWhiteSpace(m.Key) || string.IsNullOrWhiteSpace(m.Value)))
        {
            throw new ArgumentException("Metadata entries must have non-empty keys and values.", nameof(userDto.Metadata));
        }

        // Check for existing users using compiled queries (fast check first)
        if (await UserExistsByEmailAsync(userDto.Email))
        {
            throw new ValidationException($"User with email {userDto.Email} already exists.");
        }

        if (await UserExistsByUsernameAsync(userDto.UserName))
        {
            throw new ValidationException($"User with username {userDto.UserName} already exists.");
        }


        using var context = _contextFactory.CreateDbContext();
        using var transaction = await context.Database.BeginTransactionAsync();

        var hasher = new Hasher(12);
        var user = new UserModel
        {
            FirstName = userDto.FirstName,
            LastName = userDto.LastName,
            Email = userDto.Email.Trim(),
            UserName = userDto.UserName,
            Password = hasher.GenerateHashPassword(userDto.Password),
            Contact = userDto.Contact,
            Permission = ParseEnumOrDefault<TPermission>(userDto.Permission, GetFirstPermissionEnumValue).ToString() ?? "",
            Role = ParseEnumOrDefault<TRole>(userDto.Role, GetFirstRoleEnumValue).ToString() ?? "",
            Status = ParseEnumOrDefault<TStatus>(userDto.Status, GetFirstStatusEnumValue).ToString() ?? "",
            Theme = ParseEnumOrDefault<TTheme>(userDto.Theme, GetFirstThemeEnumValue).ToString() ?? "",
            ProfilePicture = userDto.ProfilePicture,
            CreatedAt = DateTimeOffset.UtcNow,
            UpdatedAt = DateTimeOffset.UtcNow,
            TimeZoneId = userDto.TimeZoneId ?? "UTC",
            Metadata = userDto.Metadata?.Any() == true
           ? userDto.Metadata
               .GroupBy(m => m.Key)
               .Select(g => g.First())
               .Select(m => new UserMetadata { Key = m.Key, Value = m.Value })
               .ToList()
           : new List<UserMetadata>()
        };

        try
        {
            context.Users.Add(user);
            await context.SaveChangesAsync();
            await transaction.CommitAsync();
            return user;
        }
        catch (DbUpdateException ex)
        {
            await transaction.RollbackAsync();
            throw new InvalidOperationException("Failed to add user due to a database error.", ex);
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            throw new InvalidOperationException("An unexpected error occurred while adding user.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<List<UserModel>> AddUserAsync(List<CreateUserDto> userDtos)
    {
        if (userDtos == null || !userDtos.Any())
        {
            throw new ArgumentNullException(nameof(userDtos), "User list cannot be null or empty.");
        }

        foreach (var userDto in userDtos)
        {
            InputValidator.Validate([userDto.FirstName, userDto.LastName, userDto.Email, userDto.UserName, userDto.Password]);
            if (!new EmailAddressAttribute().IsValid(userDto.Email))
            {
                throw new ArgumentException($"Invalid email format for user: {userDto.Email}", nameof(userDtos));
            }
            if (userDto.Metadata?.Any(m => string.IsNullOrWhiteSpace(m.Key) || string.IsNullOrWhiteSpace(m.Value)) == true)
            {
                throw new ArgumentException($"Metadata keys/values cannot be empty for user: {userDto.UserName}", nameof(userDtos));
            }
            if (userDto.TimeZoneId != null && !TimeZoneInfo.GetSystemTimeZones().Any(tz => tz.Id == userDto.TimeZoneId))
            {
                throw new ArgumentException($"Invalid TimeZoneId for user: {userDto.UserName}", nameof(userDtos));
            }
        }

        var duplicateEmails = userDtos
            .GroupBy(dto => dto.Email.Trim().ToLower())
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();
        var duplicateUserNames = userDtos
            .GroupBy(dto => dto.UserName)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();

        if (duplicateEmails.Any() || duplicateUserNames.Any())
        {
            var errors = new List<string>();
            if (duplicateEmails.Any())
                errors.Add($"Duplicate emails in input: {string.Join(", ", duplicateEmails)}");
            if (duplicateUserNames.Any())
                errors.Add($"Duplicate usernames in input: {string.Join(", ", duplicateUserNames)}");
            throw new ArgumentException($"Validation failed: {string.Join("; ", errors)}", nameof(userDtos));
        }

        var emails = userDtos.Select(dto => dto.Email.Trim().ToLower()).Distinct().ToList();
        var userNames = userDtos.Select(dto => dto.UserName).Distinct().ToList();
        using var context = _contextFactory.CreateDbContext();
        var existingUsers = await context.Users
            .AsNoTracking()
            .Where(u => emails.Contains(u.Email.ToLower()) || userNames.Contains(u.UserName))
            .Select(u => new { u.Email, u.UserName })
            .ToListAsync();

        if (existingUsers.Any())
        {
            var existingEmails = existingUsers.Select(u => u.Email.ToLower()).ToList();
            var existingUserNames = existingUsers.Select(u => u.UserName).ToList();
            var errors = new List<string>();
            if (existingEmails.Any(e => emails.Contains(e)))
                errors.Add($"Emails already exist: {string.Join(", ", emails.Where(e => existingEmails.Contains(e)))}");
            if (existingUserNames.Any(u => userNames.Contains(u)))
                errors.Add($"Usernames already exist: {string.Join(", ", userNames.Where(u => existingUserNames.Contains(u)))}");
            throw new InvalidOperationException($"Cannot add users: {string.Join("; ", errors)}");
        }

        using var transaction = await context.Database.BeginTransactionAsync();

        var hasher = new Hasher(12);
        var usersToAdd = new List<UserModel>();

        foreach (var userDto in userDtos)
        {
            var user = new UserModel
            {
                FirstName = userDto.FirstName,
                LastName = userDto.LastName,
                Email = userDto.Email.Trim(),
                UserName = userDto.UserName,
                Password = hasher.GenerateHashPassword(userDto.Password),
                Contact = userDto.Contact,
                Permission = ParseEnumOrDefault<TPermission>(userDto.Permission, GetFirstPermissionEnumValue).ToString(),
                Role = ParseEnumOrDefault<TRole>(userDto.Role, GetFirstRoleEnumValue).ToString(),
                Status = ParseEnumOrDefault<TStatus>(userDto.Status, GetFirstStatusEnumValue).ToString(),
                Theme = ParseEnumOrDefault<TTheme>(userDto.Theme, GetFirstThemeEnumValue).ToString(),
                ProfilePicture = userDto.ProfilePicture,
                CreatedAt = DateTimeOffset.UtcNow,
                UpdatedAt = DateTimeOffset.UtcNow,
                TimeZoneId = userDto.TimeZoneId ?? "UTC",
                Metadata = userDto.Metadata?.Any() == true
                    ? userDto.Metadata
                        .GroupBy(m => m.Key)
                        .Select(g => g.First())
                        .Select(m => new UserMetadata
                        {
                            Key = m.Key,
                            Value = m.Value,
                        })
                        .ToList()
                    : new List<UserMetadata>()
            };

            usersToAdd.Add(user);
        }

        try
        {
            context.Users.AddRange(usersToAdd);
            await context.SaveChangesAsync();
            await transaction.CommitAsync();
            return usersToAdd;
        }
        catch (DbUpdateException ex)
        {
            await transaction.RollbackAsync();
            throw new InvalidOperationException("Failed to add users due to a database error.", ex);
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            throw new InvalidOperationException("An unexpected error occurred while adding users.", ex);
        }
    }

    #region Helper Methods for Enum Parsing
    protected virtual T ParseEnumOrDefault<T>(object? value, Func<T> getDefaultValue) where T : struct, Enum
    {
        if (value == null) return getDefaultValue();

        if (value is T enumValue) return enumValue;

        if (value is string stringValue && Enum.TryParse<T>(stringValue, true, out T result))
            return result;

        return getDefaultValue();
    }

    protected virtual TPermission GetFirstPermissionEnumValue()
    {
        return Enum.GetValues<TPermission>().FirstOrDefault();
    }

    protected virtual TRole GetFirstRoleEnumValue()
    {
        return Enum.GetValues<TRole>().FirstOrDefault();
    }

    protected virtual TStatus GetFirstStatusEnumValue()
    {
        return Enum.GetValues<TStatus>().FirstOrDefault();
    }

    protected virtual TTheme GetFirstThemeEnumValue()
    {
        return Enum.GetValues<TTheme>().FirstOrDefault();
    }
    #endregion

    /// <inheritdoc/>
    public virtual async Task<(IEnumerable<UserModel> Users, int TotalCount)> SearchUsersAsync(
        string? searchTerm = null,
        string? role = null,
        string? status = null,
        string sortBy = "FirstName",
        bool ascending = true,
        int pageNumber = 1,
        int pageSize = 10,
        SearchMode searchMode = SearchMode.Contains,
        bool includeMetadata = false)
    {
        if (pageNumber <= 0)
            throw new ArgumentException("Page number must be greater than zero.", nameof(pageNumber));

        if (pageSize <= 0)
            throw new ArgumentException("Page size must be greater than zero.", nameof(pageSize));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            var query = context.Users.AsNoTracking();

            if (includeMetadata)
            {
                query = query.Include(u => u.Metadata);
            }

            // Generic search
            query = query.ApplySearch(searchTerm, searchMode, u => u.FirstName, u => u.LastName, u => u.Email, u => u.UserName);

            // Optional filters
            if (!string.IsNullOrWhiteSpace(role) && Enum.TryParse<TRole>(role, true, out TRole parsedRole))
            {
                query = query.Where(u => u.Role == parsedRole.ToString());
            }

            if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<TStatus>(status, true, out TStatus parsedStatus))
            {
                query = query.Where(u => u.Status == parsedStatus.ToString());
            }

            var totalCount = await query.CountAsync();

            // Apply sorting
            query = sortBy?.ToLower() switch
            {
                "firstname" => ascending ? query.OrderBy(u => u.FirstName) : query.OrderByDescending(u => u.FirstName),
                "lastname" => ascending ? query.OrderBy(u => u.LastName) : query.OrderByDescending(u => u.LastName),
                "email" => ascending ? query.OrderBy(u => u.Email) : query.OrderByDescending(u => u.Email),
                "username" => ascending ? query.OrderBy(u => u.UserName) : query.OrderByDescending(u => u.UserName),
                "createdat" => ascending ? query.OrderBy(u => u.CreatedAt) : query.OrderByDescending(u => u.CreatedAt),
                "updatedat" => ascending ? query.OrderBy(u => u.UpdatedAt) : query.OrderByDescending(u => u.UpdatedAt),
                _ => ascending ? query.OrderBy(u => u.FirstName) : query.OrderByDescending(u => u.FirstName)
            };

            // Apply pagination
            var skip = (pageNumber - 1) * pageSize;
            var users = await query
                .Skip(skip)
                .Take(pageSize)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = includeMetadata && u.Metadata != null
                        ? u.Metadata.Select(m => new UserMetadata
                        {
                            Id = m.Id,
                            UserId = m.UserId,
                            Key = m.Key,
                            Value = m.Value
                        }).ToList()
                        : new List<UserMetadata>()
                })
                .ToListAsync();

            return (users, totalCount);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while searching users.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task DeleteUserAsync(int userId)
    {
        if (userId <= 0)
            throw new ArgumentException("User ID must be greater than zero.", nameof(userId));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            using var transaction = await context.Database.BeginTransactionAsync();

            var user = await context.Users
                .Include(u => u.Metadata)
                .FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null)
                throw new InvalidOperationException($"User with ID {userId} not found.");

            // Remove user metadata first
            if (user.Metadata?.Any() == true)
            {
                context.UserMetadata.RemoveRange(user.Metadata);
            }

            // Remove the user
            context.Users.Remove(user);
            await context.SaveChangesAsync();
            await transaction.CommitAsync();
        }
        catch (DbUpdateException ex)
        {
            throw new InvalidOperationException("Failed to delete user due to a database error.", ex);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An unexpected error occurred while deleting user.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task DeleteUserAsync(IEnumerable<int> userIds)
    {
        if (userIds == null || !userIds.Any())
            throw new ArgumentException("User IDs cannot be null or empty.", nameof(userIds));

        var userIdList = userIds.Where(id => id > 0).ToList();
        if (!userIdList.Any())
            throw new ArgumentException("All user IDs must be greater than zero.", nameof(userIds));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            using var transaction = await context.Database.BeginTransactionAsync();

            var users = await context.Users
                .Include(u => u.Metadata)
                .Where(u => userIdList.Contains(u.Id))
                .ToListAsync();

            if (!users.Any())
                throw new InvalidOperationException("No users found with the provided IDs.");

            // Remove all metadata first
            var allMetadata = users.SelectMany(u => u.Metadata ?? new List<UserMetadata>()).ToList();
            if (allMetadata.Any())
            {
                context.UserMetadata.RemoveRange(allMetadata);
            }

            // Remove all users
            context.Users.RemoveRange(users);
            await context.SaveChangesAsync();
            await transaction.CommitAsync();
        }
        catch (DbUpdateException ex)
        {
            throw new InvalidOperationException("Failed to delete users due to a database error.", ex);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An unexpected error occurred while deleting users.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel?> GetUserAsync(int userId, bool includeMetadata = false)
    {
        if (userId <= 0)
            throw new ArgumentException("User ID must be greater than zero.", nameof(userId));

        try
        {
            using var context = _contextFactory.CreateDbContext();

            if (includeMetadata)
            {
                return await GetUserByIdWithMetadataQuery(context, userId);
            }
            else
            {
                return await GetUserByIdQuery(context, userId);
            }
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while retrieving user.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel?> GetUserByEmailAsync(string email, bool includeMetadata = false)
    {
        if (string.IsNullOrWhiteSpace(email))
            throw new ArgumentException("Email cannot be null or empty.", nameof(email));

        try
        {
            using var context = _contextFactory.CreateDbContext();

            if (includeMetadata)
            {
                return await GetUserByEmailWithMetadataQuery(context, email);
            }
            else
            {
                return await GetUserByEmailQuery(context, email);
            }
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while retrieving user by email.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel?> GetUserByUsernameAsync(string username, bool includeMetadata = false)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty.", nameof(username));

        try
        {
            using var context = _contextFactory.CreateDbContext();

            if (includeMetadata)
            {
                return await GetUserByUsernameWithMetadataQuery(context, username);
            }
            else
            {
                return await GetUserByUsernameQuery(context, username);
            }
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while retrieving user by username.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<PagedResult<UserModel>> GetAllUsersAsync(int pageNumber = 1, int pageSize = 10, bool includeMetadata = false)
    {
        if (pageNumber <= 0)
            throw new ArgumentException("Page number must be greater than zero.", nameof(pageNumber));

        if (pageSize <= 0)
            throw new ArgumentException("Page size must be greater than zero.", nameof(pageSize));

        try
        {
            using var context = _contextFactory.CreateDbContext();

            var totalCount = await GetTotalUsersCountQuery(context);
            var skip = (pageNumber - 1) * pageSize;

            var query = context.Users.AsNoTracking();
            if (includeMetadata)
            {
                query = query.Include(u => u.Metadata);
            }

            var users = await query
                .OrderBy(u => u.Id)
                .Skip(skip)
                .Take(pageSize)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = includeMetadata && u.Metadata != null
                        ? u.Metadata.Select(m => new UserMetadata
                        {
                            Id = m.Id,
                            UserId = m.UserId,
                            Key = m.Key,
                            Value = m.Value
                        }).ToList()
                        : new List<UserMetadata>()
                })
                .ToListAsync();

            return new PagedResult<UserModel>
            {
                Items = users,
                TotalCount = totalCount,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while retrieving all users.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserAsync(int userId, UserUpdateDto user)
    {
        if (userId <= 0)
            throw new ArgumentException("User ID must be greater than zero.", nameof(userId));

        if (user == null)
            throw new ArgumentNullException(nameof(user));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            using var transaction = await context.Database.BeginTransactionAsync();

            var existingUser = await context.Users
                .Include(u => u.Metadata)
                .FirstOrDefaultAsync(u => u.Id == userId);

            if (existingUser == null)
                throw new InvalidOperationException($"User with ID {userId} not found.");

            // Update user properties
            if (!string.IsNullOrWhiteSpace(user.FirstName))
                existingUser.FirstName = user.FirstName;

            if (!string.IsNullOrWhiteSpace(user.LastName))
                existingUser.LastName = user.LastName;

            if (!string.IsNullOrWhiteSpace(user.Email))
            {
                if (!new EmailAddressAttribute().IsValid(user.Email))
                    throw new ArgumentException("Invalid email format.", nameof(user.Email));
                existingUser.Email = user.Email.Trim().ToLowerInvariant();
            }

            if (!string.IsNullOrWhiteSpace(user.Contact))
                existingUser.Contact = user.Contact;

            if (user.ProfilePicture != null)
                existingUser.ProfilePicture = user.ProfilePicture;

            existingUser.UpdatedAt = DateTimeOffset.UtcNow;

            // Update metadata if provided
            if (user.Metadata != null)
            {
                // Remove existing metadata
                if (existingUser.Metadata?.Any() == true)
                {
                    context.UserMetadata.RemoveRange(existingUser.Metadata);
                }

                // Add new metadata
                var newMetadata = user.Metadata.Select(kvp => new UserMetadata
                {
                    UserId = userId,
                    Key = kvp.Key,
                    Value = kvp.Value
                }).ToList();

                context.UserMetadata.AddRange(newMetadata);
            }

            await context.SaveChangesAsync();
            await transaction.CommitAsync();
            return existingUser;
        }
        catch (DbUpdateException ex)
        {
            throw new InvalidOperationException("Failed to update user due to a database error.", ex);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An unexpected error occurred while updating user.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserStatusAsync(int userId, TStatus status)
    {
        var user = await UpdateUserFieldAsync(userId, "Status", status.ToString());
        return user;
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserStatusAsync(int userId, string status)
    {
        if (Enum.TryParse<TStatus>(status, true, out var parsedStatus))
        {
            var user = await UpdateUserStatusAsync(userId, parsedStatus);
            return user;
        }
        else
        {
            throw new ArgumentException($"Invalid status value: {status}", nameof(status));
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserRoleAsync(int userId, TRole role)
    {
        var user = await UpdateUserFieldAsync(userId, "Role", role.ToString());
        return user;
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserRoleAsync(int userId, string role)
    {
        if (Enum.TryParse<TRole>(role, true, out var parsedRole))
        {
            var user = await UpdateUserRoleAsync(userId, parsedRole);
            return user;
        }
        else
        {
            throw new ArgumentException($"Invalid role value: {role}", nameof(role));
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserPermissionsAsync(int userId, TPermission permission)
    {
        var user = await UpdateUserFieldAsync(userId, "Permission", permission.ToString());
        return user;
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserPermissionsAsync(int userId, string permission)
    {
        if (Enum.TryParse<TPermission>(permission, true, out var parsedPermission))
        {
            var user = await UpdateUserPermissionsAsync(userId, parsedPermission);
            return user;
        }
        else
        {
            throw new ArgumentException($"Invalid permission value: {permission}", nameof(permission));
        }
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserThemeAsync(int userId, TTheme theme)
    {
        var user = await UpdateUserFieldAsync(userId, "Theme", theme.ToString());
        return user;
    }

    /// <inheritdoc/>
    public virtual async Task<UserModel> UpdateUserThemeAsync(int userId, string theme)
    {
        if (Enum.TryParse<TTheme>(theme, true, out var parsedTheme))
        {
            var user = await UpdateUserThemeAsync(userId, parsedTheme);
            return user;
        }
        else
        {
            throw new ArgumentException($"Invalid theme value: {theme}", nameof(theme));
        }
    }

    /// <summary>
    /// Helper method to update a specific field of a user.
    /// </summary>
    /// <param name="userId">The user ID.</param>
    /// <param name="fieldName">The field name to update.</param>
    /// <param name="value">The new value.</param>
    protected virtual async Task<UserModel> UpdateUserFieldAsync(int userId, string fieldName, string value)
    {
        if (userId <= 0)
            throw new ArgumentException("User ID must be greater than zero.", nameof(userId));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            var user = await context.Users.FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null)
                throw new InvalidOperationException($"User with ID {userId} not found.");

            switch (fieldName)
            {
                case "Status":
                    user.Status = value;
                    break;
                case "Role":
                    user.Role = value;
                    break;
                case "Permission":
                    user.Permission = value;
                    break;
                case "Theme":
                    user.Theme = value;
                    break;
                default:
                    throw new ArgumentException($"Invalid field name: {fieldName}", nameof(fieldName));
            }

            user.UpdatedAt = DateTimeOffset.UtcNow;
            await context.SaveChangesAsync();
            return user;
        }
        catch (DbUpdateException ex)
        {
            throw new InvalidOperationException($"Failed to update user {fieldName} due to a database error.", ex);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"An unexpected error occurred while updating user {fieldName}.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<IEnumerable<UserModel>> GetUsersByRoleAsync(TRole role, bool includeMetadata = false, int pageNumber = 1, int pageSize = 50)
    {
        return await GetUsersByRoleAsync(role.ToString(), includeMetadata, pageNumber, pageSize);
    }

    /// <inheritdoc/>
    public virtual async Task<IEnumerable<UserModel>> GetUsersByRoleAsync(string role, bool includeMetadata = false, int pageNumber = 1, int pageSize = 50)
    {
        if (string.IsNullOrWhiteSpace(role))
            throw new ArgumentException("Role cannot be null or empty.", nameof(role));

        if (pageNumber <= 0)
            throw new ArgumentException("Page number must be greater than zero.", nameof(pageNumber));

        if (pageSize <= 0)
            throw new ArgumentException("Page size must be greater than zero.", nameof(pageSize));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            var query = context.Users.AsNoTracking().Where(u => u.Role == role);

            if (includeMetadata)
            {
                query = query.Include(u => u.Metadata);
            }

            var skip = (pageNumber - 1) * pageSize;
            var users = await query
                .OrderBy(u => u.FirstName)
                .Skip(skip)
                .Take(pageSize)
                .Select(u => new UserModel
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    UserName = u.UserName,
                    Contact = u.Contact,
                    Status = u.Status,
                    Role = u.Role,
                    Theme = u.Theme,
                    Permission = u.Permission,
                    ProfilePicture = u.ProfilePicture,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt,
                    Metadata = includeMetadata && u.Metadata != null
                        ? u.Metadata.Select(m => new UserMetadata
                        {
                            Id = m.Id,
                            UserId = m.UserId,
                            Key = m.Key,
                            Value = m.Value
                        }).ToList()
                        : new List<UserMetadata>()
                })
                .ToListAsync();

            return users;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while retrieving users by role.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<int> GetNumberOfUsersAsync()
    {
        try
        {
            using var context = _contextFactory.CreateDbContext();
            return await GetTotalUsersCountQuery(context);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while getting the number of users.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<int> GetNumberOfUsersByRoleAsync<T>(T role) where T : Enum
    {
        return await GetNumberOfUsersByRoleAsync(role.ToString());
    }

    /// <inheritdoc/>
    public virtual async Task<int> GetNumberOfUsersByRoleAsync(string role)
    {
        if (string.IsNullOrWhiteSpace(role))
            throw new ArgumentException("Role cannot be null or empty.", nameof(role));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            return await context.Users.AsNoTracking().CountAsync(u => u.Role == role);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while getting the number of users by role.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<List<T>> ExecuteRawQueryAsync<T>(string sql, params object[] parameters) where T : class
    {
        if (string.IsNullOrWhiteSpace(sql))
            throw new ArgumentException("SQL query cannot be null or empty.", nameof(sql));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            return await context.Set<T>().FromSqlRaw(sql, parameters).ToListAsync();
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while executing raw query.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<List<T>> ExecuteRawScalarQueryAsync<T>(string sql, params object[] parameters)
    {
        if (string.IsNullOrWhiteSpace(sql))
            throw new ArgumentException("SQL query cannot be null or empty.", nameof(sql));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            using var command = context.Database.GetDbConnection().CreateCommand();
            command.CommandText = sql;

            // Add parameters
            foreach (var param in parameters)
            {
                var dbParam = command.CreateParameter();
                dbParam.Value = param ?? DBNull.Value;
                command.Parameters.Add(dbParam);
            }

            await context.Database.OpenConnectionAsync();
            using var reader = await command.ExecuteReaderAsync();

            var results = new List<T>();
            while (await reader.ReadAsync())
            {
                var value = reader.GetValue(0);
                if (value != DBNull.Value)
                {
                    results.Add((T)Convert.ChangeType(value, typeof(T)));
                }
            }

            return results;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while executing raw scalar query.", ex);
        }
    }

    /// <inheritdoc/>
    public virtual async Task<int> ExecuteRawNonQueryAsync(string sql, params object[] parameters)
    {
        if (string.IsNullOrWhiteSpace(sql))
            throw new ArgumentException("SQL command cannot be null or empty.", nameof(sql));

        try
        {
            using var context = _contextFactory.CreateDbContext();
            return await context.Database.ExecuteSqlRawAsync(sql, parameters);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while executing raw non-query command.", ex);
        }
    }

    #region Dispose Pattern
    /// <summary>
    /// Disposes the resources used by the BaseDbImplementation.
    /// </summary>
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    /// <summary>
    /// Disposes the resources used by the BaseDbImplementation.
    /// </summary>
    /// <param name="disposing">True if disposing managed resources.</param>
    protected virtual void Dispose(bool disposing)
    {
        if (!_disposed && disposing)
        {
            // Dispose managed resources if any
            _disposed = true;
        }
    }
    #endregion
}