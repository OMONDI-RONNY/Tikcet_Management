namespace UserManager.Enumerations;

public enum Status
{
    Active,
    Inactive,
    Suspended,
    Pending,
    Archived,
    Deleted
}
