namespace UserManager.Enumerations;

public enum Theme
{
    SystemDefault,
    Light,
    Dark
}
