namespace UserManager.Enumerations;

public enum Role
{
    Admin,
    Manager,
    Supervisor,
    User,
    Guest
}
