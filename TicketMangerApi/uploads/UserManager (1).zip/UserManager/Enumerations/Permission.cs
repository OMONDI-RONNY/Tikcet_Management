namespace UserManager.Enumerations;

public enum Permission
{
    ReadOnly,
    ReadWrite,
    FullAccess,
    NoAccess,
    Custom
}
