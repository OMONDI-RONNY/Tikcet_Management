﻿using Microsoft.AspNetCore.Mvc;
using UserManager.Dtos;
using UserManager.Interfaces;
using UserManager.Models;
using NSCore.Models.Enums;

namespace UserManager.Controllers
{
    /// <summary>
    /// Base controller for user management operations following REST API conventions.
    /// Provides CRUD operations and user-specific functionality with proper HTTP verbs and resource naming.
    /// </summary>
    /// <typeparam name="TRole">Enumeration type for user roles</typeparam>
    /// <typeparam name="TStatus">Enumeration type for user status</typeparam>
    /// <typeparam name="TPermission">Enumeration type for user permissions</typeparam>
    /// <typeparam name="TTheme">Enumeration type for user themes</typeparam>
    [ApiController]
    [Route("api/v1/users")]
    public class UserManagerControllerBase<TRole, TStatus, TPermission, TTheme> : ControllerBase
        where TRole : struct, Enum
        where TStatus : struct, Enum
        where TPermission : struct, Enum
        where TTheme : struct, Enum
    {
        private readonly IManageUsers<TRole, TStatus, TPermission, TTheme> _userManagerHandler;

        /// <summary>
        /// Initializes a new instance of the UserManagerControllerBase.
        /// </summary>
        /// <param name="userManagerHandler">The user management service handler</param>
        /// <exception cref="ArgumentNullException">Thrown when userManagerHandler is null</exception>
        public UserManagerControllerBase(IManageUsers<TRole, TStatus, TPermission, TTheme> userManagerHandler)
        {
            _userManagerHandler = userManagerHandler ?? throw new ArgumentNullException(nameof(userManagerHandler));
        }

        /// <summary>
        /// Retrieves all users with optional filtering and pagination.
        /// </summary>
        /// <param name="pageNumber">Page number for pagination (default: 1)</param>
        /// <param name="pageSize">Number of items per page (default: 50)</param>
        /// <param name="includeMetadata">Whether to include user metadata (default: false)</param>
        /// <param name="role">Optional role filter</param>
        /// <param name="status">Optional status filter</param>
        /// <param name="search">Optional search term for name/email</param>
        /// <param name="sortBy">Optional sort term for name/email</param>
        /// <returns>Paginated list of users</returns>
        /// <response code="200">Returns the list of users</response>
        /// <response code="400">Invalid pagination parameters</response>
        [HttpGet]
        public async Task<IActionResult> Users(
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 50,
            [FromQuery] bool includeMetadata = false,
            [FromQuery] string? role = null,
            [FromQuery] string? status = null,
            [FromQuery] string? search = null,
              [FromQuery] string? sortBy = "FirstName")
        {
            // Use SearchUsersAsync for unified filtering/pagination logic
            var (users, totalCount) = await _userManagerHandler.SearchUsersAsync(
                search, role, status, sortBy, true, pageNumber, pageSize, SearchMode.Contains, includeMetadata);

            var response = new
            {
                TotalCount = totalCount,
                PageNumber = pageNumber,
                PageSize = pageSize,
                Users = users
            };

            return Ok(response);
        }

        /// <summary>
        /// Retrieves a specific user by their unique identifier.
        /// </summary>
        /// <param name="id">The unique identifier of the user</param>
        /// <param name="includeMetadata">Whether to include user metadata (default: false)</param>
        /// <returns>User details</returns>
        /// <response code="200">Returns the user</response>
        /// <response code="404">User not found</response>
        [HttpGet("{id:int}")]
        public new async Task<IActionResult> User(int id, [FromQuery] bool includeMetadata = false)
        {
            var user = await _userManagerHandler.GetUserAsync(id, includeMetadata);
            if (user == null)
                return NotFound($"User with ID {id} not found.");

            return Ok(user);
        }

        /// <summary>
        /// Retrieves a user by their email address.
        /// </summary>
        /// <param name="email">The email address of the user</param>
        /// <param name="includeMetadata">Whether to include user metadata (default: false)</param>
        /// <returns>User details</returns>
        /// <response code="200">Returns the user</response>
        /// <response code="404">User not found</response>
        [HttpGet("by-email/{email}")]
        public async Task<IActionResult> UserByEmail(string email, [FromQuery] bool includeMetadata = false)
        {
            var user = await _userManagerHandler.GetUserByEmailAsync(email, includeMetadata);
            if (user == null)
                return NotFound($"User with email {email} not found.");

            return Ok(user);
        }

        /// <summary>
        /// Retrieves users by their role.
        /// </summary>
        /// <param name="role">The role to filter by</param>
        /// <param name="includeMetadata">Whether to include user metadata (default: false)</param>
        /// <returns>List of users with the specified role</returns>
        /// <response code="200">Returns users with the specified role</response>
        /// <response code="400">Invalid role specified</response>
        [HttpGet("by-role/{role}")]
        public async Task<IActionResult> UsersByRole(TRole role, [FromQuery] bool includeMetadata = false)
        {
            var users = await _userManagerHandler.GetUsersByRoleAsync(role, includeMetadata);
            return Ok(users);
        }

        /// <summary>
        /// Retrieves a user by their username.
        /// </summary>
        /// <param name="username">The username of the user</param>
        /// <param name="includeMetadata">Whether to include user metadata (default: false)</param>
        /// <returns>User details</returns>
        /// <response code="200">Returns the user</response>
        /// <response code="404">User not found</response>
        [HttpGet("by-username/{username}")]
        public async Task<IActionResult> UserByUsername(string username, [FromQuery] bool includeMetadata = false)
        {
            var user = await _userManagerHandler.GetUserByUsernameAsync(username, includeMetadata);
            if (user == null)
                return NotFound($"User with username {username} not found.");

            return Ok(user);
        }

        /// <summary>
        /// Performs advanced search on users with parameterized SQL query.
        /// </summary>
        /// <param name="firstName">First name search pattern</param>
        /// <param name="lastName">Last name search pattern</param>
        /// <returns>List of matching users</returns>
        /// <response code="200">Returns matching users</response>
        /// <response code="400">Invalid search parameters</response>
        [HttpGet("search")]
        public async Task<ActionResult> AdvancedSearchUsers(
            [FromQuery] string firstName,
            [FromQuery] string lastName)
        {
            if (string.IsNullOrWhiteSpace(firstName) && string.IsNullOrWhiteSpace(lastName))
                return BadRequest("At least one search parameter is required.");

            try
            {
                // Using parameterized queries to prevent SQL injection
                var sql = "SELECT * FROM \"__SNUsers\" WHERE \"FirstName\" LIKE @p0 AND \"LastName\" LIKE @p1";
                var users = await _userManagerHandler.ExecuteRawQueryAsync<UserModel>(
                    sql,
                    $"%{firstName}%",
                    $"%{lastName}%"
                );

                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest($"Search failed: {ex.Message}");
            }
        }

        /// <summary>
        /// Gets the total number of users in the system.
        /// </summary>
        /// <returns>Total user count</returns>
        /// <response code="200">Returns the total user count</response>
        [HttpGet("total-count")]
        public async Task<ActionResult<int>> TotalCount()
        {
            return await _userManagerHandler.GetNumberOfUsersAsync();
        }

        /// <summary>
        /// Gets the number of users by specific role.
        /// </summary>
        /// <param name="role">The role to count users for</param>
        /// <returns>User count for the specified role</returns>
        /// <response code="200">Returns the user count for the role</response>
        /// <response code="400">Invalid role specified</response>
        [HttpGet("count-by-role")]
        public async Task<ActionResult<int>> CountByRole([FromQuery] TRole role)
        {
            return await _userManagerHandler.GetNumberOfUsersByRoleAsync<TRole>(role);
        }

        /// <summary>
        /// Creates a new user in the system.
        /// </summary>
        /// <param name="userDto">User creation data transfer object</param>
        /// <returns>Created user details</returns>
        /// <response code="201">User created successfully</response>
        /// <response code="400">Invalid user data or validation errors</response>
        /// <response code="409">User with email/username already exists</response>
        [HttpPost]
        public new async Task<IActionResult> User([FromBody] CreateUserDto userDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // 1. Check authorization using virtual hook
            if (!await CanPerformActionAsync(Actions.Create, additionalData: userDto))
                return Forbid("You don't have permission to create users.");

            // 2. Business rule validation using virtual hook
            var (isValid, errorMessage) = await ValidateBusinessRulesAsync(Actions.Create, userDto);
            if (!isValid)
                return BadRequest(errorMessage);

            try
            {
                await _userManagerHandler.AddUserAsync(userDto);
                // 3. Log the action using virtual hook
                await RecordActionAsync(Actions.Create, userDto, userDto);

                return Created("", new { Message = "Users created successfully." });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message);
            }
        }

        /// <summary>
        /// Creates multiple users in a single batch operation.
        /// </summary>
        /// <param name="users">List of user creation data transfer objects</param>
        /// <returns>Batch operation result</returns>
        /// <response code="201">Users created successfully</response>
        /// <response code="400">Invalid user data or validation errors</response>
        /// <response code="207">Partial success with some failures</response>
        [HttpPost]
        public async Task<IActionResult> Users([FromBody] List<CreateUserDto> users)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                await _userManagerHandler.AddUserAsync(users);
                return Created("", new { Message = "Users created successfully.", Count = users.Count });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Updates an existing user's information.
        /// </summary>
        /// <param name="id">The unique identifier of the user to update</param>
        /// <param name="userDto">User update data transfer object</param>
        /// <returns>No content on success</returns>
        /// <response code="204">User updated successfully</response>
        /// <response code="400">Invalid user data</response>
        /// <response code="404">User not found</response>
        [HttpPatch("{id:int}")]
        public new async Task<IActionResult> User(int id, [FromBody] UserUpdateDto userDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                await _userManagerHandler.UpdateUserAsync(id, userDto);
                // Log the action using virtual hook
                await RecordActionAsync(Actions.Update, userDto, userDto);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }

        /// <summary>
        /// Updates a user's role.
        /// </summary>
        /// <param name="id">The unique identifier of the user</param>
        /// <param name="role">The new role to assign</param>
        /// <returns>No content on success</returns>
        /// <response code="204">Role updated successfully</response>
        /// <response code="400">Invalid role</response>
        /// <response code="404">User not found</response>
        [HttpPatch("{id:int}/{role}")]
        public async Task<IActionResult> UserRole(int id, [FromQuery] string role)
        {
            try
            {
                if (!Enum.TryParse<TRole>(role, true, out var parsedRole))
                    return BadRequest($"Invalid role value: {role}");

                await _userManagerHandler.UpdateUserRoleAsync(id, role);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }

        /// <summary>
        /// Updates a user's permissions.
        /// </summary>
        /// <param name="id">The unique identifier of the user</param>
        /// <param name="permission">The new permission to assign</param>
        /// <returns>No content on success</returns>
        /// <response code="204">Permission updated successfully</response>
        /// <response code="400">Invalid permission</response>
        /// <response code="404">User not found</response>
        [HttpPatch("{id:int}/{permission}")]
        public async Task<IActionResult> UserPermission(int id, [FromQuery] string permission)
        {
            try
            {
                await _userManagerHandler.UpdateUserPermissionsAsync(id, permission);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }

        /// <summary>
        /// Updates a user's status.
        /// </summary>
        /// <param name="id">The unique identifier of the user</param>
        /// <param name="status">The new status to assign</param>
        /// <returns>No content on success</returns>
        /// <response code="204">Status updated successfully</response>
        /// <response code="400">Invalid status</response>
        /// <response code="404">User not found</response>
        [HttpPatch("{id:int}/{status}")]
        public async Task<IActionResult> UserStatus(int id, [FromQuery] string status)
        {
            try
            {
                await _userManagerHandler.UpdateUserStatusAsync(id, status);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }

        /// <summary>
        /// Updates a user's theme preference.
        /// </summary>
        /// <param name="id">The unique identifier of the user</param>
        /// <param name="theme">The new theme to assign</param>
        /// <returns>No content on success</returns>
        /// <response code="204">Theme updated successfully</response>
        /// <response code="400">Invalid theme</response>
        /// <response code="404">User not found</response>
        [HttpPatch("{id:int}/{theme}")]
        public async Task<IActionResult> UserTheme(int id, [FromQuery] string theme)
        {
            try
            {
                await _userManagerHandler.UpdateUserThemeAsync(id, theme);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }

        /// <summary>
        /// Deletes a user from the system.
        /// </summary>
        /// <param name="id">The unique identifier of the user to delete</param>
        /// <returns>No content on success</returns>
        /// <response code="204">User deleted successfully</response>
        /// <response code="404">User not found</response>
        [HttpDelete("{id:int}")]
        public new async Task<IActionResult> User(int id)
        {
            try
            {
                await _userManagerHandler.DeleteUserAsync(id);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }

        /// <summary>
        /// Deletes multiple users in a single batch operation.
        /// </summary>
        /// <param name="userIds">Collection of user IDs to delete</param>
        /// <returns>No content on success</returns>
        /// <response code="204">Users deleted successfully</response>
        /// <response code="400">Invalid user IDs</response>
        [HttpDelete]
        public async Task<IActionResult> Users([FromBody] IEnumerable<int> userIds)
        {
            if (userIds == null || !userIds.Any())
                return BadRequest("User IDs are required.");

            try
            {
                await _userManagerHandler.DeleteUserAsync(userIds);
                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Virtual authorization hook - can be overridden by implementations for custom auth logic
        /// </summary>
        /// <param name="action">The action being performed (e.g., "create", "delete", "update")</param>
        /// <param name="userId">Optional user ID for user-specific operations</param>
        /// <param name="additionalData">Any additional data needed for authorization</param>
        /// <returns>True if authorized, false otherwise</returns>
        protected virtual async Task<bool> CanPerformActionAsync(Actions action, int? userId = null, object? additionalData = null)
        {
            // Default implementation - always allow (no authorization)
            await Task.CompletedTask;
            return true;
        }

        /// <summary>
        /// Virtual hook for data validation beyond model validation
        /// </summary>
        /// <param name="action">The action being performed</param>
        /// <param name="data">The data being validated</param>
        /// <returns>Validation result</returns>
        protected virtual async Task<(bool IsValid, string? ErrorMessage)> ValidateBusinessRulesAsync(Actions action, object data)
        {
            // Default implementation - always valid
            await Task.CompletedTask;
            return (true, null);
        }

        /// <summary>
        /// Virtual hook for logging/auditing actions
        /// </summary>
        /// <param name="action">The action performed</param>
        /// <param name="oldData">The old data</param>
        /// <param name="newData">The new data</param>
        protected virtual async Task RecordActionAsync(Actions action, object oldData, object newData)
        {
            // Default implementation - do nothing
            await Task.CompletedTask;
        }
    }
}