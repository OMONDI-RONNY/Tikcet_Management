﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManager.Models;

namespace UserManager.Dtos
{
    public class UserDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DisplayName => $"{FirstName} {LastName}";
        public string Email { get; set; }
        public string UserName { get; set; }
        public string? Contact { get; set; }
        public string? Status { get; set; }
        public string? Role { get; set; }
        public string? Theme { get; set; }
        public string? Permission { get; set; }
        public string? ProfilePicture { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
        public DateTimeOffset UpdatedAt { get; set; }
        public string TimeZoneId { get; set; }
        public List<UserMetadata> Metadata { get; set; } = new();
    }

}
