using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using NSCore.DatabaseContext;
using UserManager.DbImplementation;
using UserManager.Dtos;
using UserManager.Enumerations;
using UserManager.Interfaces;
using UserManager.LazyLoading;
using UserManager.Models;
using UserManager.Services;
using UserManager.Data;
using NSCore.DatabaseProviders;
using NSCatch.Interfaces;

namespace UserManager;

/// <summary>
/// Manages user-related operations such as adding, deleting, and updating users.
/// </summary>
public class ManageUsers : ManageUsers<Role, Status, Permission, Theme>
{
    /// <summary>
    /// Initializes a new instance of the ManageUsers class.
    /// </summary>
    /// <param name="config">The database configuration.</param>
    /// <param name="contextFactory">The database context factory.</param>
    /// <param name="cacheManager">The cache manager instance.</param>
    /// <param name="keyBuilder">The cache key builder instance.</param>
    /// <param name="applyMigrationsAutomatically">Whether to apply migrations automatically.</param>
    public ManageUsers(IDatabaseConfig config, IDbContextFactory<AppDbContext> contextFactory, ICacheManager cacheManager, ICacheKeyBuilder keyBuilder, bool applyMigrationsAutomatically = true) : base(config, contextFactory, cacheManager, keyBuilder, applyMigrationsAutomatically) { }
}

/// <summary>
/// Manages user-related operations such as adding, deleting, and updating users.
/// </summary>
public class ManageUsers<TRole, TStatus, TPermission, TTheme> : BackgroundService, IManageUsers<TRole, TStatus, TPermission, TTheme> where TRole : struct, Enum where TStatus : struct, Enum where TPermission : struct, Enum where TTheme : struct, Enum
{
    private IManageUsers<TRole, TStatus, TPermission, TTheme> _connection;
    private bool _isContextCreated;
    private bool _applyMigrationsAutomatically;
    private LazyLoadManager _userLoadManager;
    private INsContextInit _initializer;

    private readonly ICacheManager _cacheManager;
    private readonly ICacheKeyBuilder _keyBuilder;

    // private readonly CacheService _cacheService;

    /// <summary>
    /// Initializes a new instance of the ManageUsers class with cache support.
    /// </summary>
    /// <param name="config">The database configuration.</param>
    /// <param name="contextFactory">The database context factory.</param>
    /// <param name="cacheManager">The cache manager instance.</param>
    /// <param name="keyBuilder">The cache key builder instance.</param>
    /// <param name="applyMigrationsAutomatically">Whether to apply migrations automatically.</param>
    public ManageUsers(IDatabaseConfig config, IDbContextFactory<AppDbContext> contextFactory,
        ICacheManager cacheManager, ICacheKeyBuilder keyBuilder, bool applyMigrationsAutomatically = true)
    {
        _applyMigrationsAutomatically = applyMigrationsAutomatically;
        this._cacheManager = cacheManager;
        this._keyBuilder = keyBuilder;
        //_cacheService = new CacheService(_cacheManager, _keyBuilder);

        _connection = config switch
        {
            SQLDb => new SQL<TRole, TStatus, TPermission, TTheme>(contextFactory),
            PSQLDb => new PostgreSQL<TRole, TStatus, TPermission, TTheme>(contextFactory),
            MySQLDb => new MySQL<TRole, TStatus, TPermission, TTheme>(contextFactory),
            _ => throw new ArgumentException("Unsupported database type.")
        };

        if (_connection == null)
            throw new InvalidOperationException("Failed to initialize a valid INsContextInitializer.");
        _initializer = _connection as INsContextInit ?? throw new InvalidOperationException("Failed to initialize a valid INsContextInitializer.");
        InitializeLazyLoadingSystem();
    }

    /// <inheritdoc/>
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (_connection == null)
        {
            throw new InvalidOperationException("Database connection is not initialized.");
        }

        if (_applyMigrationsAutomatically)
        {
            await _initializer.ApplyMigrationsAsync(stoppingToken);
        }

        if (_initializer.IsContextCreated())
        {
            _isContextCreated = true;
        }
    }

    private void InitializeLazyLoadingSystem()
    {
        var dataService = new DataService(pageSize: 10, fetchDataFunc: (from, pageSize) => FetchUsersAsync(from, pageSize, includeMetadata: false));
        _userLoadManager = new LazyLoadManager(dataService);
    }

    #region Cache Key generators
    private string BuildUserKey(int id)
    {
        using var sha256 = System.Security.Cryptography.SHA256.Create();
        var idBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(id.ToString()));
        var hashString = Convert.ToBase64String(idBytes)
            .Replace("+", "-")
            .Replace("/", "_")
            .TrimEnd('=');

        string cacheKey = _keyBuilder.BuildKey(prefix: $"User_{hashString}");
        return cacheKey;
    }

    private string BuildUsersKey()
    {
        string cacheKey = _keyBuilder.BuildKey(prefix: $"Users_General");
        return cacheKey;
    }

    private string BuildRolesKey(string role, bool includeMetadata = false, int pageNumber = 1, int pageSize = 10)
    {
        using var sha256 = System.Security.Cryptography.SHA256.Create();
        var input = $"{role}{includeMetadata}{pageNumber}{pageSize}";
        var roleBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input));
        var hashString = Convert.ToBase64String(roleBytes).Replace("+", "-").Replace("/", "").TrimEnd('=');

        string cacheKey = _keyBuilder.BuildKey(prefix: $"Roles_{hashString}");
        return cacheKey;
    }

    private string BuildRolesKey(TRole role, bool includeMetadata = false, int pageNumber = 1, int pageSize = 10)
    {
        using var sha256 = System.Security.Cryptography.SHA256.Create();
        var input = $"{role.ToString()}{includeMetadata}{pageNumber}{pageSize}";
        var roleBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input));
        var hashString = Convert.ToBase64String(roleBytes).Replace("+", "-").Replace("/", "").TrimEnd('=');

        string cacheKey = _keyBuilder.BuildKey(prefix: $"Roles_{hashString}");
        return cacheKey;
    }

    private string BuildUsernameKey(string username)
    {
        using var sha256 = System.Security.Cryptography.SHA256.Create();
        string truncatedUsername = username.Length > 50 ? username.Substring(0, 50) : username;
        var roleBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(truncatedUsername));
        var hashString = Convert.ToBase64String(roleBytes).Replace("+", "-").Replace("/", "_").TrimEnd('=');

        string cacheKey = _keyBuilder.BuildKey(prefix: $"Users_Username_{hashString}");
        return cacheKey;
    }

    private string BuildEmailKey(string email)
    {
        using var sha256 = System.Security.Cryptography.SHA256.Create();
        string truncatedEmail = email.Length > 50 ? email.Substring(0, 50) : email;
        var roleBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(truncatedEmail));
        var hashString = Convert.ToBase64String(roleBytes).Replace("+", "-").Replace("/", "_").TrimEnd('=');

        string cacheKey = _keyBuilder.BuildKey(prefix: $"Users_Email_{hashString}");
        return cacheKey;
    }

    private string BuildFetchUsersKey(int from = 0, int pageSize = 10, bool includeMetadata = false)
    {
        using var sha256 = System.Security.Cryptography.SHA256.Create();
        var input = $"{from}{pageSize}{includeMetadata}";
        var bytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input));
        var hashString = Convert.ToBase64String(bytes).Replace("+", "-").Replace("/", "_").TrimEnd('=');

        string cacheKey = _keyBuilder.BuildKey(prefix: $"Users{hashString}");
        return cacheKey;

    }

    private string BuildSearchUsersKey(string? searchTerm, string? role, string? status, string sortBy, bool ascending, int page, int pageSize, SearchMode searchMode, bool includeMetadata = false)
    {
        using var sha256 = System.Security.Cryptography.SHA256.Create(); var input = $"{searchTerm ?? "null"}{role ?? "null"}{status ?? "null"}{sortBy}{ascending}{page}{pageSize}{searchMode}{includeMetadata}"; var bytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input)); var hashString = Convert.ToBase64String(bytes).Replace("+", "-").Replace("/", "_").TrimEnd('=');

        string cacheKey = _keyBuilder.BuildKey(prefix: $"SearchUsers{hashString}");
        return cacheKey;

    }

    #endregion

    /// <inheritdoc/>
    public Task<List<UserModel>> FetchUsersAsync(int from = 0, int pageSize = 10, bool includeMetadata = false)
    {
        EnsureContext();
        return _cacheManager.GetOrSetAsync<List<UserModel>>(key: BuildFetchUsersKey(), () => _connection.FetchUsersAsync(from, pageSize, includeMetadata));
    }

    /// <inheritdoc/>
    public async Task<List<UserModel>> AddUserAsync(List<CreateUserDto> users)
    {
        EnsureContext();

        List<UserModel> createdUsers;
        createdUsers = await _connection.AddUserAsync(users);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Concat(createdUsers).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }
        return createdUsers;
    }

    /// <inheritdoc/>
    public async Task<UserModel> AddUserAsync(CreateUserDto user)
    {
        EnsureContext();

        UserModel createdUser;
        createdUser = await _connection.AddUserAsync(user);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Concat(new[] { createdUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }
        return createdUser;
    }

    /// <inheritdoc/>
    public async Task<(IEnumerable<UserModel> Users, int TotalCount)> SearchUsersAsync(string? searchTerm, string? role, string? status, string sortBy, bool ascending, int page, int pageSize, SearchMode searchMode, bool includeMetadata = false)
    {
        EnsureContext();

        var searchCacheKey = BuildSearchUsersKey(searchTerm, role, status, sortBy, ascending, page, pageSize, searchMode);
        var result = await _cacheManager.GetOrSetAsync(searchCacheKey, async () =>
        {
            var tuppleResult = await _connection.SearchUsersAsync(searchTerm, role, status, sortBy, ascending, page, pageSize, searchMode, includeMetadata);
            return new SearchUsersResult(tuppleResult.Users, tuppleResult.TotalCount);
        });
        return (result.Users, result.TotalCount);
    }

    /// <inheritdoc/>
    public async Task DeleteUserAsync(int userId)
    {
        EnsureContext();

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }
        else
        {
            await _cacheManager.RemoveAsync(generalCacheKey);
        }
    }

    /// <inheritdoc/>
    public async Task DeleteUserAsync(IEnumerable<int> userIds)
    {
        EnsureContext();
        await _connection.DeleteUserAsync(userIds);

        foreach (var id in userIds)
        {
            var userCacheKey = BuildUserKey(id);
            await _cacheManager.RemoveAsync(userCacheKey);
        }

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => !userIds.Contains(u.Id)).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }
        else
        {
            await _cacheManager.RemoveAsync(generalCacheKey);
        }
    }

    /// <inheritdoc/>
    public async Task<PagedResult<UserModel>> GetAllUsersAsync(int pageNumber = 1, int pageSize = 10, bool includeMetadata = false)
    {
        EnsureContext();
        return await _cacheManager.GetOrSetAsync<PagedResult<UserModel>>(key: BuildUsersKey(), () => _connection.GetAllUsersAsync(pageNumber: pageNumber, pageSize: pageSize, includeMetadata: includeMetadata));
    }

    /// <inheritdoc/>
    public async Task<UserModel?> GetUserAsync(int userId, bool includeMetadata = false)
    {
        EnsureContext();
        return await _cacheManager.GetOrSetAsync<UserModel>(BuildUserKey(userId),
        () => _connection.GetUserAsync(userId, includeMetadata));
    }


    /// <inheritdoc/>
    public async Task<UserModel?> GetUserByEmailAsync(string email, bool includeMetadata = false)
    {
        EnsureContext();
        return await _cacheManager.GetOrSetAsync<UserModel>(key: BuildEmailKey(email: email), () => _connection.GetUserByEmailAsync(email, includeMetadata));
    }

    /// <inheritdoc/>
    public async Task<UserModel?> GetUserByUsernameAsync(string username, bool includeMetadata = false)
    {
        EnsureContext();
        return await _cacheManager.GetOrSetAsync<UserModel>(key: BuildUsernameKey(username: username), () => _connection.GetUserByUsernameAsync(username, includeMetadata));
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<UserModel>> GetUsersByRoleAsync(TRole role, bool includeMetadata = false, int pageNumber = 1, int pageSize = 10)
    {
        EnsureContext();
        return await _cacheManager.GetOrSetAsync<IEnumerable<UserModel>>(key: BuildRolesKey(role: role), () => _connection.GetUsersByRoleAsync(role, includeMetadata, pageNumber, pageSize));
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<UserModel>> GetUsersByRoleAsync(string role, bool includeMetadata = false, int pageNumber = 1, int pageSize = 10)
    {
        EnsureContext();
        return await _cacheManager.GetOrSetAsync<IEnumerable<UserModel>>(key: BuildRolesKey(role: role), () => _connection.GetUsersByRoleAsync(role, includeMetadata, pageNumber, pageSize));
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserAsync(int userId, UserUpdateDto user)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserAsync(userId, user);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserPermissionsAsync(int userId, TPermission permission)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserPermissionsAsync(userId, permission);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserPermissionsAsync(int userId, string permission)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserPermissionsAsync(userId, permission);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserRoleAsync(int userId, TRole role)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserRoleAsync(userId, role);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserRoleAsync(int userId, string role)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserRoleAsync(userId, role);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserStatusAsync(int userId, TStatus status)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserStatusAsync(userId, status);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserStatusAsync(int userId, string status)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserStatusAsync(userId, status);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserThemeAsync(int userId, TTheme theme)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserThemeAsync(userId, theme);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<UserModel> UpdateUserThemeAsync(int userId, string theme)
    {
        EnsureContext();

        UserModel updatedUser;
        updatedUser = await _connection.UpdateUserThemeAsync(userId, theme);

        var userCacheKey = BuildUserKey(userId);
        await _cacheManager.RemoveAsync(userCacheKey);

        var generalCacheKey = BuildUsersKey();
        var cachedUsers = await _cacheManager.GetAsync<List<UserModel>>(generalCacheKey);

        if (cachedUsers != null)
        {
            var updatedUsers = cachedUsers.Where(u => u.Id != userId).Concat(new[] { updatedUser }).ToList();
            await _cacheManager.SetAsync(generalCacheKey, updatedUsers);
        }

        return updatedUser;
    }

    /// <inheritdoc/>
    public async Task<int> GetNumberOfUsersAsync()
    {
        EnsureContext();
        return await _connection.GetNumberOfUsersAsync();
    }

    /// <inheritdoc/>
    public async Task<int> GetNumberOfUsersByRoleAsync<TRole>(TRole role) where TRole : Enum
    {
        EnsureContext();
        return await _connection.GetNumberOfUsersByRoleAsync(role);
    }

    /// <inheritdoc/>
    public async Task<int> GetNumberOfUsersByRoleAsync(string role)
    {
        EnsureContext();
        return await _connection.GetNumberOfUsersByRoleAsync(role);
    }

    /// <inheritdoc/>
    public async Task<List<T>> ExecuteRawQueryAsync<T>(string sql, params object[] parameters) where T : class
    {
        EnsureContext();

        // For queries that return entity objects
        return await _connection.ExecuteRawQueryAsync<T>(sql, parameters);
    }

    /// <inheritdoc/>
    public Task<List<T>> ExecuteRawScalarQueryAsync<T>(string sql, params object[] parameters)
    {
        EnsureContext();

        // For queries that return simple scalar values
        return _connection.ExecuteRawScalarQueryAsync<T>(sql, parameters);
    }

    /// <inheritdoc/>
    public Task<int> ExecuteRawNonQueryAsync(string sql, params object[] parameters)
    {
        EnsureContext();

        // For commands that modify data (INSERT/UPDATE/DELETE)
        return _connection.ExecuteRawNonQueryAsync(sql, parameters);
    }

    /// <summary>
    /// Ensures that the context has been properly initialized.
    /// Throws a NotInitializedException if the context is not created.
    /// </summary>
    private void EnsureContext()
    {
        if (!_isContextCreated)
        {
            throw new InvalidOperationException("Failed to initialize the database context.");
        }
    }
}

public record SearchUsersResult(IEnumerable<UserModel> Users, int TotalCount);