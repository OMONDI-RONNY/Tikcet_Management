using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using NSCore.DatabaseProviders;
using UserManager.Enumerations;
using UserManager.Models;

namespace UserManager.Data;

/// <summary>
/// Represents the database context for user management operations.
/// </summary>
public class AppDbContext : DbContext
{
    /// <summary>
    /// Initializes a new instance of the AppDbContext class.
    /// </summary>
    /// <param name="options">The options to be used by the DbContext.</param>
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    /// <summary>
    /// Configures the schema needed for the identity framework.
    /// </summary>
    /// <param name="modelBuilder">The builder being used to construct the model for this context.</param>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<UserModel>(entity =>
        {
            entity.ToTable("__SNUsers");
            entity.HasKey(u => u.Id); ;
        });

        modelBuilder.Entity<UserMetadata>(entity =>
        {
            entity.ToTable("__SNUserMetadata");
            entity.HasIndex(u => new { u.UserId, u.Key }).IsUnique();
        });

        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<UserModel>()
            .HasIndex(u => u.Email)
            .IsUnique();
        modelBuilder.Entity<UserModel>()
            .HasIndex(u => u.UserName)
            .IsUnique();

        if (Database.IsNpgsql())
        {
            modelBuilder.Entity<UserModel>()
                .Property(u => u.DisplayName)
                .HasComputedColumnSql("\"FirstName\" || ' ' || \"LastName\"", stored: true);
        }
        else if (Database.IsMySql())
        {
            modelBuilder.Entity<UserModel>()
                .Property(u => u.DisplayName)
                .HasComputedColumnSql("CONCAT(FirstName, ' ', LastName)", stored: true);
        }
        else if (Database.IsSqlServer())
        {
            modelBuilder.Entity<UserModel>()
                .Property(u => u.DisplayName)
                .HasComputedColumnSql("[FirstName] + ' ' + [LastName]", stored: true);
        }

        base.OnModelCreating(modelBuilder);
    }

    /// <summary>
    /// Gets or sets the Users DbSet.
    /// </summary>
    public DbSet<UserModel> Users { get; set; }
    
    /// <summary>
    /// Gets or sets the UserMetadata DbSet.
    /// </summary>
    public DbSet<UserMetadata> UserMetadata { get; set; }
}
