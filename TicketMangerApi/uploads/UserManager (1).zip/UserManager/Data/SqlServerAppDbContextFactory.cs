using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using static UserManager.Data.AppDbContextVariants;

namespace UserManager.Data;

/// <summary>
/// Design-time factory for creating SqlServerAppDbContext instances during migration operations.
/// </summary>
public class SqlServerAppDbContextFactory : IDesignTimeDbContextFactory<SqlServerAppDbContext>
{
    /// <summary>
    /// Creates a new instance of SqlServerAppDbContext for design-time operations.
    /// </summary>
    /// <param name="args">Command-line arguments.</param>
    /// <returns>A configured SqlServerAppDbContext instance.</returns>
    public SqlServerAppDbContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
        // var connectionString = "Server=localhost;Database=file_manager_sql;User Id=sa;Password=yourpassword;";
        var connectionString = "Server=localhost;Database=user_manager_sql;Trusted_Connection=True;TrustServerCertificate=True;";
        optionsBuilder.UseSqlServer(connectionString);
        return new SqlServerAppDbContext(optionsBuilder.Options);
    }
}
