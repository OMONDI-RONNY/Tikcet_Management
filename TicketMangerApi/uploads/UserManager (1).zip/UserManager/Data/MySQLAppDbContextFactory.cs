using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using static UserManager.Data.AppDbContextVariants;

namespace UserManager.Data;

/// <summary>
/// Design-time factory for creating MySQLAppDbContext instances during migration operations.
/// </summary>
public class MySQLAppDbContextFactory : IDesignTimeDbContextFactory<MySQLAppDbContext>
{
   /// <summary>
   /// Creates a new instance of MySQLAppDbContext for design-time operations.
   /// </summary>
   /// <param name="args">Command-line arguments.</param>
   /// <returns>A configured MySQLAppDbContext instance.</returns>
   public MySQLAppDbContext CreateDbContext(string[] args)
   {
       var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
       // TO-DO: Update this connection string as needed
       var connectionString = "Server=localhost;Database=user_manager_mysql;User=root;Password=35688410;";
       optionsBuilder.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
       return new MySQLAppDbContext(optionsBuilder.Options);
   }
}
