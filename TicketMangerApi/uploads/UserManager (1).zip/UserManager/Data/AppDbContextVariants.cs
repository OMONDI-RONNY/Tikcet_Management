using System;
using Microsoft.EntityFrameworkCore;

namespace UserManager.Data;

/// <summary>
/// Contains database-specific DbContext variants used for EF Core migrations.
/// These are primarily for design-time migration generation and are not used at runtime.
/// </summary>
public static class AppDbContextVariants
{
    /// <summary>
    /// PostgreSQL-specific DbContext variant for migration generation.
    /// </summary>
    public class PostgresAppDbContext : AppDbContext
    {
        /// <summary>
        /// Initializes a new instance of the PostgresAppDbContext class.
        /// </summary>
        /// <param name="options">The options to be used by the DbContext.</param>
        public PostgresAppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }

    /// <summary>
    /// SQL Server-specific DbContext variant for migration generation.
    /// </summary>
    public class SqlServerAppDbContext : AppDbContext
    {
        /// <summary>
        /// Initializes a new instance of the SqlServerAppDbContext class.
        /// </summary>
        /// <param name="options">The options to be used by the DbContext.</param>
        public SqlServerAppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }

    /// <summary>
    /// MySQL-specific DbContext variant for migration generation.
    /// </summary>
    public class MySQLAppDbContext : AppDbContext
    {
        /// <summary>
        /// Initializes a new instance of the MySQLAppDbContext class.
        /// </summary>
        /// <param name="options">The options to be used by the DbContext.</param>
        public MySQLAppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }
}
