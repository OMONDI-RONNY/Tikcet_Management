using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using static UserManager.Data.AppDbContextVariants;

namespace UserManager.Data;

/// <summary>
/// Design-time factory for creating PostgresAppDbContext instances during migration operations.
/// </summary>
public class PostgresAppDbContextFactory : IDesignTimeDbContextFactory<PostgresAppDbContext>
{
   /// <summary>
   /// Creates a new instance of PostgresAppDbContext for design-time operations.
   /// </summary>
   /// <param name="args">Command-line arguments.</param>
   /// <returns>A configured PostgresAppDbContext instance.</returns>
   public PostgresAppDbContext CreateDbContext(string[] args)
   {
       var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
       var connectionString = "Host=localhost;Port=5432;Database=user_manager_pg;Username=postgres;Password=35688410";
       optionsBuilder.UseNpgsql(connectionString);
       return new PostgresAppDbContext(optionsBuilder.Options);
   }
}
